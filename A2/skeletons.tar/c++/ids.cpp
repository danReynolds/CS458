#include <iostream>
#include <pcap.h>

int main(int argc, char* argv[]) {
		std::cout << "Hello, world!" << std::endl;
		return 0;
}